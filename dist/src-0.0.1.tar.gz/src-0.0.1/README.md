create env
'''
bash
conda create -n wineq python=3.7 -y
'''